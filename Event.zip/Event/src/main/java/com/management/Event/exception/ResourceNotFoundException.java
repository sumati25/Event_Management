package com.management.Event.exception;



public class ResourceNotFoundException extends Exception {
	
	 public ResourceNotFoundException(String message){
	        super(message);
	    }

}
